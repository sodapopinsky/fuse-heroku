(function() {
  'use strict';

  angular
    .module('fuse')
    .run(runBlock);

  /** @ngInject */
  function runBlock() {
    //$log.debug('runBlock end');
  }

})();
