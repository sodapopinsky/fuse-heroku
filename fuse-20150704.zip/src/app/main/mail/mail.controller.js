(function () {
    'use strict';

    angular.module('fuse')
        .controller('mailController', mailController);

    /** @ngInject */
    function mailController(api) {
        var vm = this;
        vm.colors = ['blue', 'blue-grey', 'orange', 'pink', 'purple'];
        vm.selected = [];
        vm.selectMail = selectMail;
        vm.selectionToggle = selectionToggle;
        vm.selectionExists = selectionExists;
        vm.selectAll = selectAll;
        vm.selectedMail = {};
        vm.selectedAccount = 'creapond';
        vm.accounts = {
            'creapond': 'sercanyemen@creapond.com',
            'withinpixels': 'sercanyemen@withinpixels.com'
        };

        api.mail.inbox.get({}, function (response) {
            vm.inbox = response.data;
            vm.selectedMail = vm.inbox[0];
        });

        function selectMail(mail) {
            vm.selectedMail = mail;
        }

        function selectionToggle(item, list) {
            var idx = list.indexOf(item);
            if (idx > -1) list.splice(idx, 1);
            else list.push(item);
        }

        function selectionExists(item, list) {
            return list.indexOf(item) > -1;
        }

        function selectAll() {
            if (vm.selected.length > 0) {
                vm.selected = [];
                vm.allSelected = false;
            } else {
                vm.selected = angular.copy(vm.inbox);
                angular.forEach(vm.inbox, function (mail) {
                    selectionToggle(mail, vm.selected);
                });
                vm.allSelected = true;
            }
        }
    }
})();
