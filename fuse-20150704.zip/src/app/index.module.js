(function() {
  'use strict';

    /**
     * @ngdoc overview
     * @name fuse
     * @description
     * # fuse
     *
     * Main module of the application.
     */
    angular
        .module('fuse', [
            'app.core'
        ]);

})();
