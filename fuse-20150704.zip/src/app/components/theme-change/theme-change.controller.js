(function () {
    'use strict';

    angular.module('app.core')
        .controller('ThemeChangeController', ThemeChangeController);

    /** @ngInject */
    function ThemeChangeController($rootScope, $route, palettes, wipThemes, themeService) {
        var vm = this;
        vm.isOpen = false;
        vm.setTheme = setTheme;
        vm.themes = wipThemes;
        vm.getThemeColor = getThemeColor;

        function setTheme(themeName, themePalette) {
            $rootScope.appTheme = themeName;
            themeService.generateThemePaletteCss(themePalette);
            //for update chart colors
            $route.reload();
        }

        function getThemeColor(paletteColor, level, op) {
            op = op || 1;
            var rgb = angular.copy(palettes[paletteColor.name][level].value);
            rgb.push(op);
            //console.log(rgb);

            return 'rgba(' + rgb.join() + ')';
        }

        function getPrimaryColor(theme) {
            var rgb = palettes[theme.palette.primary]['500'].value;
            return 'rgb(' + rgb.join() + ')';
        }
    }

    function assign(obj, keyPath, value) {
        var lastKeyIndex = keyPath.length - 1;
        for (var i = 0; i < lastKeyIndex; ++i) {
            var key = keyPath[i];
            if (!(key in obj))
                obj[key] = {}
            obj = obj[key];
        }
        obj[keyPath[lastKeyIndex]] = value;
    }
})();
