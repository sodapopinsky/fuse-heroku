(function() {
  'use strict';

  angular
    .module('fuse')
    .run(runBlock);

  /** @ngInject */
  function runBlock($log) {
    //$log.debug('runBlock end');
  }

})();
